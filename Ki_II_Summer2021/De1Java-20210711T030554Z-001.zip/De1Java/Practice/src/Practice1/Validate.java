/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Practice1;

/**
 *
 * @author alias
 */
public class Validate {
    
    //neu id cua book bat dau voi chu FF thi book dc giam gia 10%
    public double f1(Book b){
        double price = 0;
        
        
        return price;  
    }
    //hien thi date cua book theo dang yyyy-MM-dd
    public void f3(Book b){
        
    }
    //neu month cua date la thang 2 thi in ra Name sach. neu khong in ra ID cua sach
    public void f4(Book b){
        
    }
    
}
